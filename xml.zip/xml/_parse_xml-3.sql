declare
  vErrMsg             varchar2(2000);
  cCrmes              varchar2(2000);  
  vClob               clob;
 
procedure Save_Xml_Exp(p_SendID    in number,
                              p_SendType  in number,
                              p_xml       in clob)
    is

    RESPONSE_OK  constant number := 1;

    /*cvVariable varchar2(2000);
    nvConfidenceFlag number;
    nvScoreCardType  number;
    nvScoreInterval  number;
    nvScoreNumber    number;*/

    vStrVal          varchar2(2000);
    FatalError       boolean;
    ResponseCode     varchar2(20);
    ivResponseCode   number;
    Response_string  varchar2(2000);
    vResult          varchar2(2000);
    LastRecord       number;
    DoSaveFlag       boolean;


    vXML                xmltype;
    i_node  xmldom.domnode;
    i_con_node xmldom.domnode;
    l_nlist xmldom.domnodelist;

     requestnum                   number;

     accountclass                 number;
     accountcloseddate            date;
     accountholdercomments        varchar2(150);
     accountpaymentstatus         varchar2(1);
     accountspecialstatus         varchar2(2);
     amountinsuredloan            number;
     amountoffinance              number;
     arrearsbalance               number;
     consumeraccountnumber        varchar2(40);
     creditfacilitystatus         varchar2(1);
     creditlimit                  number;
     currency                     varchar2(3);
     dateaccountadded             date;
     defaultdate                  date;
     duration                     number;
     durationunit                 varchar2(2);
     financetype                  varchar2(2);
     fulfilmentduedate            date;
     instalment                   number;
     insuredloan                  varchar2(1);
     interestrate                 number;
     lastmissedpaymentdate        date;
     lastpaymentdate              date;
     lastupdatets                 date;
     litigationdate               date;
     monthoflastupdate            date;
     numofapplicants              number;
     opendate                     date;
     outstandingbalance           number;
     paymentfrequency             varchar2(2);
     purposeoffinance             varchar2(2);
     reasonforclosure             varchar2(2);
     recordblockdisputeindicator  varchar2(1);
     subscribercomments           varchar2(250);
     subscribername               varchar2(40);
     typeofsecurity               varchar2(1);
     worstpaymentstatus           varchar2(1);
     writeoffdate                 date;
     accountholdertype            varchar2(2);

     WorstCurrentPayStatusOwner   varchar2(1);
     WorstCurrentPayStatusJoint   varchar2(1);
     WorstEverPayStatusOwner      varchar2(1);
     CAISRecordsOwner             number;
     CAISRecordsJoint             number;

     CAPSLast3MonthsOwner         number;
     CAPSLast3MonthsJoint         number;
     CAPSLast3MonthsReferee       number;
     CAPSLast3MonthsGuarantor     number;

     PrivateEntrepreneurEGRN      varchar2(2000);

    procedure ValueOf(p_Node dbms_xmldom.DOMNode, p_val in out nocopy number, p_Item varchar2, p_level number default 1)
    is
        l_val   varchar2(4000);
    begin
        l_val := ubrr_xml_parsing.get_attr_value(p_node, p_Item, p_level);
        p_val := to_number(l_val, '9999999999999990D99999999', 'NLS_NUMERIC_CHARACTERS=''. ''');
    end;

    procedure ValueOf(p_Node dbms_xmldom.DOMNode, p_val in out nocopy varchar2, p_Item varchar2, p_level number  default 1)
    is
        l_val   varchar2(4000);
    begin
        l_val := ubrr_xml_parsing.get_attr_value(p_node, p_Item, p_level);
        p_val := dbms_xmlgen.convert(l_val, dbms_xmlgen.entity_decode);
    end;

    procedure ValueOf(p_Node dbms_xmldom.DOMNode, p_val in out nocopy date, p_Item varchar2, p_level number  default 1)
    is
        l_val   varchar2(4000);
    begin
        l_val := ubrr_xml_parsing.get_attr_value(p_node, p_Item, p_level);
        p_val := to_date(l_val, 'yyyymmddhh24miss');
    end;

begin
  ---------------------------------
            vXML := XMLType.createXML(p_xml);

            ivResponseCode := RESPONSE_OK;
            FatalError := false;
            DoSaveFlag := true;
            Requestnum := p_SendID;

            if not UBRR_VLV.Ubrr_Xml_Parsing.IsAssigned(vXML, 'errorCode', 2) then
              --'������ ����������� ���� "��� ������"'
              FatalError := true;
            else
              Responsecode :=  Ubrr_Xml_Parsing.get_attr_value(vXML, 'errorCode', 2);
              if Responsecode <> '0' then
                 --����� ������
                 ivResponseCode := ubrr_str_pak_bki.GetSprCode(pType => p_SendType, pSprId => 3, pSprCode => Responsecode, pMain => false);
                 Response_string := '������ �����';
                 FatalError := true;
              end if;
            end if;

            dbms_output.put_line('Responsecode='||Responsecode );

            if not FatalError then
               i_con_node := Ubrr_Xml_Parsing.getNodeByTagName(vXML, 'Consumer');
               if DBMS_XMLDOM.isNull(i_con_node) then
                  Responsecode := '1';
                  Response_string := '������� � ������ ������� �� ������';
               else
                  i_node := Ubrr_Xml_Parsing.getNodeByTagName(i_con_node, 'CAIS');

                  if not DBMS_XMLDOM.isNull(i_node) then --����� ���� CAIS
                    
                  dbms_output.put_line('������ ���� '||  UBRR_VLV.ubrr_xml_parsing.getNodeName(i_node) );

                  l_nlist := DBMS_XMLDOM.getchildnodes(i_node);
                  IF NOT DBMS_XMLDOM.isNull(l_nlist)/* and DBMS_XMLDOM.getLength(l_nlist)>1 */THEN
                    
                  dbms_output.put_line('� ����� ���������: '|| DBMS_XMLDOM.getLength(l_nlist) );
                  
                      Responsecode := '0';
                      FOR i IN 0 .. DBMS_XMLDOM.getLength(l_nlist) - 1 LOOP
                        
                        

                        Responsecode := '0';
                        if i = DBMS_XMLDOM.getLength(l_nlist) - 1 then
                            LastRecord := 1;
                        else
                            LastRecord := 0;
                        end if;


                        i_node := DBMS_XMLDOM.item(l_nlist, i);
                        
                        dbms_output.put_line(  DBMS_XMLDOM.getNodeName(i_node));

                          CAISRecordsOwner := null;
                          CAISRecordsJoint := null;
                             ValueOf(i_node, accountclass, 'accountclass');
                        ValueOf(i_node, accountcloseddate, 'accountcloseddate');
                    ValueOf(i_node, accountholdercomments, 'accountholdercomments');
                    ValueOf(i_node, accountpaymentstatus, 'accountpaymentstatus');
                     ValueOf(i_node, accountspecialstatus, 'accountspecialstatus');
                        ValueOf(i_node, amountinsuredloan, 'amountinsuredloan');
                          ValueOf(i_node, amountoffinance, 'amountoffinance');
                           ValueOf(i_node, arrearsbalance, 'arrearsbalance');
                    ValueOf(i_node, consumeraccountnumber, 'consumeraccountnumber');
                     ValueOf(i_node, creditfacilitystatus, 'creditfacilitystatus');
                              ValueOf(i_node, creditlimit, 'creditlimit');
                                 ValueOf(i_node, currency, 'currency');
                         ValueOf(i_node, dateaccountadded, 'dateaccountadded');
                              ValueOf(i_node, defaultdate, 'defaultdate');
                                 ValueOf(i_node, duration, 'duration');
                             ValueOf(i_node, durationunit, 'durationunit');
                              ValueOf(i_node, financetype, 'financetype');
                        ValueOf(i_node, fulfilmentduedate, 'fulfilmentduedate');
                               ValueOf(i_node, instalment, 'instalment');
                              ValueOf(i_node, insuredloan, 'insuredloan');
                             ValueOf(i_node, interestrate, 'interestrate');
                    ValueOf(i_node, lastmissedpaymentdate, 'lastmissedpaymentdate');
                          ValueOf(i_node, lastpaymentdate, 'lastpaymentdate');
                             ValueOf(i_node, lastupdatets, 'lastupdatets');
                           ValueOf(i_node, litigationdate, 'litigationdate');
                        ValueOf(i_node, monthoflastupdate, 'monthoflastupdate');
                          ValueOf(i_node, numofapplicants, 'numofapplicants');
                                 ValueOf(i_node, opendate, 'opendate');
                       ValueOf(i_node, outstandingbalance, 'outstandingbalance');
                         ValueOf(i_node, paymentfrequency, 'paymentfrequency');
                         ValueOf(i_node, purposeoffinance, 'purposeoffinance');
                         ValueOf(i_node, reasonforclosure, 'reasonforclosure');
              ValueOf(i_node, recordblockdisputeindicator, 'recordblockdisputeindicator');
                       ValueOf(i_node, subscribercomments, 'subscribercomments');
                           ValueOf(i_node, subscribername, 'subscribername');
                           ValueOf(i_node, typeofsecurity, 'typeofsecurity');
                       ValueOf(i_node, worstpaymentstatus, 'worstpaymentstatus');
                             ValueOf(i_node, writeoffdate, 'writeoffdate');

                      --������ ��������� ��� ������ ��������� ����� �� ���� Consumer
                      i_node := Ubrr_Xml_Parsing.getNodeByTagName(i_node, 'Consumer');
                      ValueOf(i_node, accountholdertype, 'accountHolderType', 2);
                      ValueOf(i_node, PrivateEntrepreneurEGRN, 'PrivateEntrepreneurEGRN', 2);
                      --������ ��������� �������� ���� - ������������� ��� ������
                      i_node := Ubrr_Xml_Parsing.getNodeByTagName(i_con_node, 'Summary');

                      ValueOf(i_node, WorstCurrentPayStatusOwner, 'WorstCurrentPayStatusOwner');
                      ValueOf(i_node, WorstCurrentPayStatusJoint, 'WorstCurrentPayStatusJoint');
                      ValueOf(i_node, WorstEverPayStatusOwner, 'WorstEverPayStatusOwner');
                      ValueOf(i_node, CAISRecordsOwner, 'CAISRecordsOwner');
                      ValueOf(i_node, CAISRecordsJoint, 'CAISRecordsJoint');
                      ValueOf(i_node, CAPSLast3MonthsOwner, 'CAPSLast3MonthsOwner');
                      ValueOf(i_node, CAPSLast3MonthsJoint, 'CAPSLast3MonthsJoint');
                      ValueOf(i_node, CAPSLast3MonthsReferee, 'CAPSLast3MonthsReferee');
                      ValueOf(i_node, CAPSLast3MonthsGuarantor, 'CAPSLast3MonthsGuarantor');

                      vResult := UBRR_VLV.ubrr_str_pak_bki.EXPSaveReceive(Requestnum, Responsecode, LastRecord,
                       accountclass,
                       accountcloseddate, accountholdercomments,
                       accountpaymentstatus, accountspecialstatus,
                       amountinsuredloan, amountoffinance, arrearsbalance,
                       consumeraccountnumber, creditfacilitystatus, creditlimit,
                       currency, dateaccountadded, defaultdate, duration,
                       durationunit, financetype, fulfilmentduedate, instalment,
                       insuredloan, interestrate, lastmissedpaymentdate,
                       lastpaymentdate, lastupdatets, litigationdate,
                       monthoflastupdate, numofapplicants, opendate,
                       outstandingbalance, paymentfrequency, purposeoffinance,
                       reasonforclosure, recordblockdisputeindicator,
                       subscribercomments, subscribername, typeofsecurity,
                       worstpaymentstatus, writeoffdate, accountholdertype,
                       --�����
                       WorstCurrentPayStatusOwner, WorstCurrentPayStatusJoint,
                       WorstEverPayStatusOwner, CAISRecordsOwner, CAISRecordsJoint,
                       CAPSLast3MonthsOwner,
                       CAPSLast3MonthsJoint,
                       CAPSLast3MonthsReferee,
                       CAPSLast3MonthsGuarantor,
                       privateEntrepreneurEGRN,
                       --���������
                       Response_string);

                       DoSaveFlag := false;

                      END LOOP;
                      -- ����� � ����� CAIS ���� ������
                   else
                      Responsecode := '-4';
                      Response_string := '��������� ������� �� �������';
                      dbms_output.put_line('1');
                     ---------------------------------------------
                   END IF; -- � ����� CAIS �����

                   ELSE -- ���� CAIS ���
                      Responsecode := '-4';
                      Response_string := '��������� ������� �� �������';
                                            dbms_output.put_line('2');
                   END IF;

                    i_node := Ubrr_Xml_Parsing.getNodeByTagName(i_con_node, 'CAPS');
                    l_nlist := DBMS_XMLDOM.getchildnodes(i_node);

                    if DBMS_XMLDOM.isNull(i_node) or (DBMS_XMLDOM.isNull(l_nlist) and DBMS_XMLDOM.getLength(l_nlist)>1 ) then
                      i_node := Ubrr_Xml_Parsing.getNodeByTagName(i_con_node, 'Summary');

                      if not DBMS_XMLDOM.isNull(i_node) then
                        ValueOf(i_node, vStrVal, 'CAPSRecordsOwnerBeforeFilter');
                        if nvl(vStrVal, '0' ) <> '0' then
                          responsecode := '-6';
                        end if;

                        ValueOf(i_node, vStrVal, 'CAPSRecordsJointBeforeFilter');
                        if nvl(vStrVal, '0' ) <> '0' then
                          responsecode := '-6';
                        end if;

                        ValueOf(i_node, vStrVal, 'APSRecordsGuarantorBeforeFilter');
                        if nvl(vStrVal, '0' ) <> '0' then
                          responsecode := '-6';
                        end if;

                        ValueOf(i_node, vStrVal, 'APSRecordsRefereeBeforeFilter');
                        if nvl(vStrVal, '0' ) <> '0' then
                          responsecode := '-6';
                        end if;

                        if responsecode = '-6' then
                          Response_String := '���������� ������';
                        else
                          ResponseCode := '1';
                          Response_String := '������� � ������ ������� �� ������';
                        end if;
                      end if;
                    end if;
                   ---------------------------------------------
                     
                    if DoSaveFlag then
                          vResult := UBRR_VLV.ubrr_str_pak_bki.EXPSaveReceive(Requestnum, Responsecode, LastRecord,
                               accountclass,
                               accountcloseddate, accountholdercomments,
                               accountpaymentstatus, accountspecialstatus,
                               amountinsuredloan, amountoffinance, arrearsbalance,
                               consumeraccountnumber, creditfacilitystatus, creditlimit,
                               currency, dateaccountadded, defaultdate, duration,
                               durationunit, financetype, fulfilmentduedate, instalment,
                               insuredloan, interestrate, lastmissedpaymentdate,
                               lastpaymentdate, lastupdatets, litigationdate,
                               monthoflastupdate, numofapplicants, opendate,
                               outstandingbalance, paymentfrequency, purposeoffinance,
                               reasonforclosure, recordblockdisputeindicator,
                               subscribercomments, subscribername, typeofsecurity,
                               worstpaymentstatus, writeoffdate, accountholdertype,
                               --�����
                               WorstCurrentPayStatusOwner, WorstCurrentPayStatusJoint,
                               WorstEverPayStatusOwner, CAISRecordsOwner, CAISRecordsJoint,
                               CAPSLast3MonthsOwner,
                               CAPSLast3MonthsJoint,
                               CAPSLast3MonthsReferee,
                               CAPSLast3MonthsGuarantor,
                               privateEntrepreneurEGRN,
                               --���������
                               Response_string);
                    end if;
                   
               end if;
            end if;
            
dbms_output.put_line('responsecode='||responsecode||', Response_String='||  Response_String);

end;              
      

--
--end;
 

begin

  for rec in ( select cXml
from ubrr_cre_response r
where requestnum = 22046963) loop
  
    -- cCrmes := UBRR_VLV.ubrr_str_pak_bki.save_xml(vErrMsg, 234832/*1414623*/, rec.xml_response); 
    Save_Xml_Exp(1,1,rec.cxml);
   /* 
    dbms_output.put_line('cCrmes='||cCrmes);
    dbms_output.put_line('vErrMsg='||vErrMsg);     
      */

  end loop;

exception
  when others then
    dbms_output.put_line(dbms_utility.format_error_stack ||
                         dbms_utility.format_error_backtrace);
end;
