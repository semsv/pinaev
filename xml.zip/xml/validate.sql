begin
    for i in (select object_id, object_name, OBJECT_TYPE
              from all_objects
              where status = 'INVALID'
              and ( lower(object_name) like '%scoring%' or lower(object_name) like  '%bki%' )
              )
    loop
        begin
            dbms_utility.validate (i.object_id);
        exception
            when others then
                dbms_output.put_line (sqlerrm);
        end;
    end loop;
    commit;
end;

