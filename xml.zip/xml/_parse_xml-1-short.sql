declare
  vErrMsg             varchar2(2000);
  vClob               clob;
  vXML                xmltype;
  vNsMap              varchar2(200);
  cvStatus            varchar2(20);
  cvMainRules         varchar2(32767);
  ivMainScoreValue    number;
  cvSpecificRules     varchar2(32767);
  ivApplicationsFound number;

  ---    vStr varchar2(2000);

  function xml_get_text(pXML        xmltype,
                        cpXPath     varchar2,
                        cpNsmap     varchar2,
                        bpMandatory boolean default false) return varchar2 is
  begin
    return dbms_xmlgen.convert(pXML.extract(cpXPath, cpNsmap)
                               .getStringVal(),
                               dbms_xmlgen.ENTITY_DECODE);
  exception
    when others then
      if sqlcode = -30625 then
        if bpMandatory then
          raise_application_error(-20000,
                                  '�� ������ ������� ' || cpXPath);
        else
          return null;
        end if;
      else
        raise;
      end if;
  end;

  function xml_to_number(pMes varchar2) return number is
    cvMes varchar2(2000);
  begin
    cvMes := replace(pMes, '.', ',');
    return to_number(cvMes);
  exception
    when others then
      cvMes := replace(pMes, ',', '.');
      return to_number(cvMes);
  end;

  /* -----------------------------------------------------------------------------------------
  
  ����������� �������, ������� ���������� �������� ���� (TagValue) � �������� ������ (TagName)  ����:
  <a n="TagName">TagValue</a> 
  ������� ����������� ����� ���� ����� ����������
  
  --------------------------------------------------------------------------------------------*/

  function get_attr_value(p_xmlDoc    XMLType,
                          p_attr_name varchar2,
                          pNsMap      varchar2) return varchar2 is
    xmlDoc     XMLType;
    i_node     xmldom.domnode;
    l_nlist    xmldom.domnodelist;
    l_doc      DBMS_XMLDOM.DOMDocument;
    vAttrValue varchar2(2000);
    
    function getNodeValue(p_i_node xmldom.domnode) return varchar2 is
      vCTTI     VARCHAR2(32000);
      vRet1     varchar2(2000);
      vAttrName varchar2(50);
    begin
      if DBMS_XMLDOM.getNodeName(p_i_node) = 'a' then
        DBMS_XMLDOM.writeToBuffer(p_i_node, vCTTI);
        xmlDoc    := XMLType.createXML(vCTTI);
        vAttrName := xml_get_text(xmlDoc, '/a/@n', pNsMap);
        if vAttrName = p_attr_name then
          vRet1 := xml_get_text(xmlDoc, '/a', pNsMap);
          vRet1 := regexp_substr(vRet1, '>[[:alnum:]]{1,}<');
          vRet1 := replace(replace(vRet1, '<'), '>');
        end if;
      end if;
      return vRet1;
    end;
  
    function is_parent_node(p_i_node xmldom.domnode) return boolean is
      l_nlist_tmp xmldom.domnodelist;
    begin
      l_nlist_tmp := DBMS_XMLDOM.getchildnodes(p_i_node);
      if DBMS_XMLDOM.getLength(l_nlist_tmp) = 1 and
         DBMS_XMLDOM.getNodeName(DBMS_XMLDOM.item(l_nlist_tmp, 0)) =
         '#text' then
        return false;
      else
        return true;
      end if;
    
    end;
  
    function getValue(p_l_nlist xmldom.domnodelist) return varchar2 is
      vRet varchar2(2000);
    begin
      IF NOT DBMS_XMLDOM.isNull(p_l_nlist) THEN
        FOR i IN 0 .. DBMS_XMLDOM.getLength(p_l_nlist) - 1 LOOP
        
          i_node := DBMS_XMLDOM.item(p_l_nlist, i);
        
          if is_parent_node(i_node) then
            vRet := getValue(DBMS_XMLDOM.getchildnodes(i_node));
          else
            vRet := getNodeValue(i_node); -- �������, ��� �� ������� ��������� � i-� ����
          end if;
        
          if vRet is not null then
            return vRet;
          end if;
        
        end loop;
      end if;
      return vRet;
    end;
  
  begin
    xmlDoc     := Null;
    l_doc      := DBMS_XMLDOM.newdomdocument(p_xmlDoc);
    l_nlist    := DBMS_XMLDOM.getchildnodes(DBMS_XMLDOM.makeNode(l_doc));
    vAttrValue := getValue(l_nlist);
    return vAttrValue;
  end;
--------------


  function IsAssigned(p_xmlDoc    XMLType,
                      p_attr_name varchar2, 
                      pNsMap varchar2) return boolean is
                      
    xmlDoc     XMLType;
    i_node     xmldom.domnode;
    l_nlist    xmldom.domnodelist;    
    l_doc      DBMS_XMLDOM.DOMDocument;
    
   function getNodeValue(p_i_node xmldom.domnode, p_node_name varchar2) return boolean is
      vCTTI     VARCHAR2(32000);
      vAttrName varchar2(50);
    begin
        DBMS_XMLDOM.writeToBuffer(p_i_node, vCTTI);
        xmlDoc    := XMLType.createXML(vCTTI);
        vAttrName := xml_get_text(xmlDoc, '/'|| p_node_name ||'/@n', pNsMap);
        if vAttrName = p_attr_name then
          return true;
        end if;

      return false;
    end;
    
    function is_parent_node(p_i_node xmldom.domnode) return boolean is
      l_nlist_tmp xmldom.domnodelist;
    begin
      l_nlist_tmp := DBMS_XMLDOM.getchildnodes(p_i_node);
      if DBMS_XMLDOM.getLength(l_nlist_tmp) = 1 and
         DBMS_XMLDOM.getNodeName(DBMS_XMLDOM.item(l_nlist_tmp, 0)) =
         '#text' then
        return false;
      else
        return true;
      end if;
    
    end;
  
    function getValue(p_l_nlist xmldom.domnodelist) return boolean is
         vRet       boolean;
    begin
       vRet := false;
      
      IF NOT DBMS_XMLDOM.isNull(p_l_nlist) THEN
        FOR i IN 0 .. DBMS_XMLDOM.getLength(p_l_nlist) - 1 LOOP
        
          i_node := DBMS_XMLDOM.item(p_l_nlist, i);
          
          if getNodeValue(i_node, DBMS_XMLDOM.getNodeName(i_node) ) then
             vRet := true;
             return vRet;
          end if;  
          
          if is_parent_node(i_node) then
            vRet := getValue(DBMS_XMLDOM.getchildnodes(i_node));
          end if;    
          
        end loop;
      end if;
      
      return vRet;
    end;
  
  begin
    
    xmlDoc     := Null;
    l_doc      := DBMS_XMLDOM.newdomdocument(p_xmlDoc);
    l_nlist    := DBMS_XMLDOM.getchildnodes(DBMS_XMLDOM.makeNode(l_doc));
    return getValue(l_nlist);
    
  end;

--------------


begin

  for rec in (select t.file_name from ubrr_vdata.ubrr_cre_test_1 t where file_name='a2721639.xml') loop
  
    select xml_response
      into vClob
      from ubrr_vdata.ubrr_cre_test_1
     where file_name = rec.file_name;
    vXML := XMLType.createXML(vClob);
  
/*    dbms_output.put_line('file_name=' || rec.file_name ||
                         ',errorCode      =' ||
                         get_attr_value(vXML, 'errorCode', ''));
    dbms_output.put_line('file_name=' || rec.file_name ||
                         ',confidenceFlag =' ||
                         get_attr_value(vXML, 'confidenceFlag', ''));
    dbms_output.put_line('file_name=' || rec.file_name ||
                         ',scoreCardType  =' ||
                         get_attr_value(vXML, 'scoreCardType', ''));
    dbms_output.put_line('file_name=' || rec.file_name ||
                         ',scoreInterval  =' ||
                         get_attr_value(vXML, 'scoreInterval', ''));
    dbms_output.put_line('file_name=' || rec.file_name ||
                         ',scoreNumber    =' ||
                         get_attr_value(vXML, 'scoreNumber', ''));
*/                         

    if isAssigned( vXML, 'Consumer', null ) then
    dbms_output.put_line('file_name=' || rec.file_name || ' Consumer Assigned');
    else
    dbms_output.put_line('file_name=' || rec.file_name || ' Consumer NOT Assigned!!!!');
    end if;  
                         
                         
  end loop;

  --    dbms_output.put_line('vXml.getNamespace='||vXml.getNamespace);

  /*    vNsMap :=
  'xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:ns1="http://example.org/FPSPartner"';
  
  */

  /*
  if vXML.existsnode('/SOAP-ENV:Envelope/SOAP-ENV:Body/ns1:outputVectorResponse/status', vNsMap) = 1 then
      cvStatus := xml_get_text(vXML, '/SOAP-ENV:Envelope/SOAP-ENV:Body/ns1:outputVectorResponse/status/text()', vNsMap);
  else
      cvStatus := '-3';
  end if;
  
  cvMainRules := xml_get_text(vXML, '/SOAP-ENV:Envelope/SOAP-ENV:Body/ns1:outputVectorResponse/mainrules/text()', vNsMap);
  ivMainScoreValue :=
      xml_to_number(xml_get_text(vXML,
                                 '/SOAP-ENV:Envelope/SOAP-ENV:Body/ns1:outputVectorResponse/mainscorevalue/text()',
                                 vNsMap));
  cvSpecificRules :=
      xml_get_text(vXML, '/SOAP-ENV:Envelope/SOAP-ENV:Body/ns1:outputVectorResponse/specificrules/text()', vNsMap);
  
  ivApplicationsFound :=
      xml_to_number(xml_get_text(vXML,
                                 '/SOAP-ENV:Envelope/SOAP-ENV:Body/ns1:outputVectorResponse/applicationsfound/text()',
                                 vNsMap));
  
  dbms_output.put_line('cvStatus          ' || cvStatus);
  dbms_output.put_line('cvMainRules       ' || cvMainRules);
  dbms_output.put_line('ivMainScoreValue  ' || ivMainScoreValue);
  dbms_output.put_line('cvSpecificRules   ' || cvSpecificRules);
  dbms_output.put_line('ivApplicationsFound ' || ivApplicationsFound);
  */
exception
  when others then
    dbms_output.put_line(dbms_utility.format_error_stack ||
                         dbms_utility.format_error_backtrace);
end;
