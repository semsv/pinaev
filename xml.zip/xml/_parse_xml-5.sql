declare

vXML                  xmltype;


procedure save_xml is
          ivResponseCode  number;
          cvMessage              varchar2(2000);
           cvMes varchar2(2000);
           
             vErrCode  varchar2(20);
        vMessage  varchar2(2000);
        cvVariable varchar2(2000);
        nvConfidenceFlag number;
        nvScoreCardType  number;
        nvScoreInterval  number;
        nvScoreNumber    number;
        bFatalError      boolean;
        i_node     xmldom.domnode;
           
begin
  


                vErrCode := ubrr_xml_parsing.get_attr_value(vXML, 'errorCode');
                
                   dbms_output.put_line('vErrCode='||vErrCode);
                
                if  vErrCode <> '0' then
                   ivResponseCode := UBRR_VLV.ubrr_str_pak_bki.GetSprCode(pType =>5,pSprId => 3, pSprCode => vErrCode,pMain => false);
                   vMessage := '������ ����� � ����� ' ||vErrCode;
                   --cvMes := SendFatalMess(cMess => vMessage, prequestnum => ipSendID);
                elsif not ubrr_xml_parsing.isAssigned(vXML, 'Consumer') then
                      ivResponseCode := 3;
                      vMessage := '������� � ������ ������� �� ������';
                elsif not ubrr_xml_parsing.isAssigned(vXML, 'BureauScore',3) then
                      ivResponseCode := -5;
                      vMessage := '�������-������ �� �������';
                else
                      i_node :=   ubrr_xml_parsing.getNodeByTagName(vXML, 'BureauScore',3);
                      
                      if ubrr_xml_parsing.is_parent_node(i_node) then  -->><<-- 30.12.2016 ������
                        null;
                         /* nvConfidenceFlag := xml_to_number(ubrr_xml_parsing.get_attr_value( i_node, 'confidenceFlag') );
                          nvScoreCardType  := xml_to_number(ubrr_xml_parsing.get_attr_value( i_node, 'scoreCardType') );
                          nvScoreInterval  := xml_to_number(ubrr_xml_parsing.get_attr_value( i_node, 'scoreInterval') );
                          nvScoreNumber    := xml_to_number(ubrr_xml_parsing.get_attr_value( i_node, 'scoreNumber') );*/
                          
                         /* if ubrr_xml_parsing.isAssigned(vXML, 'Summary') then
                             i_node :=   ubrr_xml_parsing.getNodeByTagName(vXML, 'Summary',3);

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'CAISRECORDSOWNERRECIP', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'CAISRECORDSOWNERRECIP', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'WORSTCURRENTPAYSTATUSOWNER', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'WORSTCURRENTPAYSTATUSOWNER', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'WORSTEVERPAYSTATUSOWNER', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'WORSTEVERPAYSTATUSOWNER', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'CAISRECORDSJOINTRECIP', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'CAISRECORDSJOINTRECIP', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'WORSTCURRENTPAYSTATUSJOINT', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'WORSTCURRENTPAYSTATUSJOINT', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'WORSTEVERPAYSTATUSJOINT', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'WORSTEVERPAYSTATUSJOINT', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'CAISRECORDSGUARANTORRECIP', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'CAISRECORDSGUARANTORRECIP', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'WORSTCURRENTPAYSTATUSGUARANTOR', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'WORSTCURRENTPAYSTATUSGUARANTOR', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'CAISRECORDSREFEREERECIP', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'CAISRECORDSREFEREERECIP', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'WORSTCURRENTPAYSTATUSREFEREE', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'WORSTCURRENTPAYSTATUSREFEREE', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'TOTALMONTHLYINSTALMENTSOWNER', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'TOTALMONTHLYINSTALMENTSOWNER', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'TOTALOUTSTANDINGBALANCEOWNER', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'TOTALOUTSTANDINGBALANCEOWNER', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'TOTALMONTHLYINSTALMENTSALLBUTOWNER', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'TOTALMONTHLYINSTALMENTSALLBUTOWNER', pValue =>  cvVariable );
                             end if;

                             cvVariable := ubrr_xml_parsing.get_attr_value(i_node, 'TOTALOUTSTANDINGBALANCEALLBUTOWNER', null);
                             if cvVariable is not null then
                               SetOutParam(ipSendId => ipSendID, pName => 'TOTALOUTSTANDINGBALANCEALLBUTOWNER', pValue =>  cvVariable );
                             end if;
                          end if;                          */
                      -->>-- 30.12.2016 ������    
                      else
                          ivResponseCode := -5;
                          vMessage := '�������-������ �� �������';
                      end if;
                      --<<-- 30.12.2016 ������    

                end if;

               /* if ivResponseCode = RESPONSE_OK then
                   EXPSaveScore(ipRequestNum => ipSendID,
                   ipConfidenceFlag => nvConfidenceFlag,
                   ipScoreCardType => nvScoreCardType,
                   ipScoreInterval => nvScoreInterval,
                   ipScoreNumber => nvScoreNumber);
                 end if;*/

                -- updateRequest(ipRequestNum => ipSendID,ipCode => ivResponseCode,cpResponseString =>vMessage);
                
                dbms_output.put_line('vResponseCode='||ivResponseCode||',  vMessage='|| vMessage);
                
            exception
                when others then
                  null;
                   -- cvMes := 'ivSendType ' || ivSendType || chr(10) || dbms_utility.format_error_stack || dbms_utility.format_error_backtrace;
                    --cvMes := SendFatalMess(cMess => cvMes, prequestnum => ipSendID);

dbms_output.put_line('Exception: vResponseCode='||ivResponseCode||',  ivResponseCode='|| ivResponseCode);


end;  


begin
for rec in 
  (
select * from ubrr_cre_response
where BKI_ID=5 and CODE_SYS='EI' and requestnum in  (23598728, 23523150)  and CREATE_DATE > '15.12.2016' 
  )  loop
  
  dbms_output.put_line('REQUESTNUM='||rec.REQUESTNUM);
  
    vXML := XMLType.createXML(rec.cxml);
    
    
    
    save_xml;
  
  end loop;

end;  
