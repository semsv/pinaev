declare

  vClob                 clob;
  vXML                  xmltype;
  
  RESPONSE_OK  constant number := 1; -->><<-- 11.11.2016 ������
  -->> 03.11.2016 ������ �.�. 16-2428
        vErrCode  varchar2(20);
        vMessage  varchar2(2000);
        cvVariable varchar2(2000);
        nvConfidenceFlag number;
        nvScoreCardType  number;
        nvScoreInterval  number;
        nvScoreNumber    number;
        bFatalError      boolean;
        --<< 03.11.2016 ������ �.�. 16-2428
         cvMes varchar2(2000);
        
         ivResponseCode   number;
         
            i_node     xmldom.domnode;
    l_nlist    xmldom.domnodelist;
    l_doc      DBMS_XMLDOM.DOMDocument;
         
----

 --->>> 23.03.2015  ������� �.�.     15-95     #20419 ������: ���������� �������� �������-�������
    function xml_to_number(pMes varchar2) return number
    is
      cvMes varchar2(2000);
    begin
      cvMes := replace(pMes,'.',',');
      return to_number(cvMes);
    exception
      when others then
        cvMes := replace(pMes,',','.');
        return to_number(cvMes);
    end;


procedure parse_xml is
begin  
  
            ivResponseCode := RESPONSE_OK;
            vMessage := null;
            begin
                vErrCode := ubrr_xml_parsing.get_attr_value(vXML, 'errorCode');
                
                dbms_output.put_line('vErrCode='||vErrCode);
                
                if  vErrCode <> '0' then
                   --ivResponseCode := GetSprCode(pType => BKI_EXPSCORE,pSprId => 3, pSprCode => vErrCode,pMain => false);
                   vMessage := '������ ����� � ����� ' ||vErrCode;
                   
dbms_output.put_line('vErrCode='||vErrCode);
                   
                   -------------------cvMes := SendFatalMess(cMess => vMessage, prequestnum => ipSendID);
                elsif not ubrr_xml_parsing.isAssigned(vXML, 'Consumer') then
                  
                  dbms_output.put_line('Consumer not found..');
                  
                      ivResponseCode := 3;
                      vMessage := '������� � ������ ������� �� ������';
                elsif not ubrr_xml_parsing.isAssigned(vXML, 'BureauScore',3) then
                      ivResponseCode := -5;
                      
                  dbms_output.put_line('BureauScore not assigned..');
                                        
                      vMessage := '�������-������ �� �������';
                else
                  
                  dbms_output.put_line('nvConfidenceFlag='||ubrr_xml_parsing.get_attr_value(vXML, 'confidenceFlag', 10)); 
                  
                  i_node :=   ubrr_xml_parsing.getNodeByTagName(vXML, 'BureauScore',3);
                  
                   dbms_output.put_line( DBMS_XMLDOM.getNodeName(i_node));
                  
                      dbms_output.put_line('nvConfidenceFlag='||ubrr_xml_parsing.get_attr_value(i_node, 'confidenceFlag')); 
                
                      nvConfidenceFlag := xml_to_number(ubrr_xml_parsing.get_attr_value(vXML, 'confidenceFlag', 7) );
                      nvScoreCardType  := xml_to_number(ubrr_xml_parsing.get_attr_value(vXML, 'scoreCardType', 6) );
                      nvScoreInterval  := xml_to_number(ubrr_xml_parsing.get_attr_value(vXML, 'scoreInterval, 6') );
                      nvScoreNumber    := xml_to_number(ubrr_xml_parsing.get_attr_value(vXML, 'scoreNumber', 6) );
                      
                     --  dbms_output.put_line('nvConfidenceFlag='||nvConfidenceFlag);

                      /*if ubrr_xml_parsing.isAssigned(vXML, 'Summary', null) then

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'CAISRECORDSOWNERRECIP', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'CAISRECORDSOWNERRECIP', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'WORSTCURRENTPAYSTATUSOWNER', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'WORSTCURRENTPAYSTATUSOWNER', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'WORSTEVERPAYSTATUSOWNER', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'WORSTEVERPAYSTATUSOWNER', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'CAISRECORDSJOINTRECIP', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'CAISRECORDSJOINTRECIP', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'WORSTCURRENTPAYSTATUSJOINT', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'WORSTCURRENTPAYSTATUSJOINT', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'WORSTEVERPAYSTATUSJOINT', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'WORSTEVERPAYSTATUSJOINT', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'CAISRECORDSGUARANTORRECIP', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'CAISRECORDSGUARANTORRECIP', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'WORSTCURRENTPAYSTATUSGUARANTOR', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'WORSTCURRENTPAYSTATUSGUARANTOR', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'CAISRECORDSREFEREERECIP', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'CAISRECORDSREFEREERECIP', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'WORSTCURRENTPAYSTATUSREFEREE', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'WORSTCURRENTPAYSTATUSREFEREE', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'TOTALMONTHLYINSTALMENTSOWNER', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'TOTALMONTHLYINSTALMENTSOWNER', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'TOTALOUTSTANDINGBALANCEOWNER', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'TOTALOUTSTANDINGBALANCEOWNER', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'TOTALMONTHLYINSTALMENTSALLBUTOWNER', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'TOTALMONTHLYINSTALMENTSALLBUTOWNER', pValue =>  cvVariable );
                         end if;

                         cvVariable := ubrr_xml_parsing.get_attr_value(vXML, 'TOTALOUTSTANDINGBALANCEALLBUTOWNER', null);
                         if cvVariable is not null then
                           SetOutParam(ipSendId => ipSendID, pName => 'TOTALOUTSTANDINGBALANCEALLBUTOWNER', pValue =>  cvVariable );
                         end if;
                      end if;*/

                end if;

             /*   if ivResponseCode = RESPONSE_OK then
                   EXPSaveScore(ipRequestNum => ipSendID,
                   ipConfidenceFlag => nvConfidenceFlag,
                   ipScoreCardType => nvScoreCardType,
                   ipScoreInterval => nvScoreInterval,
                   ipScoreNumber => nvScoreNumber);
                 end if;*/

                -- updateRequest(ipRequestNum => ipSendID,ipCode => ivResponseCode,cpResponseString =>vMessage);
            exception
                when others then
                    cvMes := 'ivSendType ' || /*ivSendType || chr(10) || */dbms_utility.format_error_stack || dbms_utility.format_error_backtrace;
                   -- cvMes := SendFatalMess(cMess => cvMes, prequestnum => ipSendID);

            end;

end;


begin
  

 select CXML into vClob
from ubrr_cre_response
where requestnum in (22046568);

vXML := XMLType.createXML(vClob);

parse_xml;


end;  
