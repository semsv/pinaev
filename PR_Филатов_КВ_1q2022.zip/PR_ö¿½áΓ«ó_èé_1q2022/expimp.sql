--procedura vigruzki dannih iz svyazannih tablic SL_MESS i SL_TASK_MESS
PROCEDURE ExpMess(TT in out Temp_Table, TableName IN VARCHAR2, Filter IN VARCHAR2)
IS
  c1     DynamicCursor;        --dinamicheskij kursor dlya SL_MESS
  c2     DynamicCursor;        --dinamicheskij kursor dlya SL_TASK_MESS
  rec1   SL_MESS%ROWTYPE;      --zapis' tablici SL_MESS
  rec2   SL_TASK_MESS%ROWTYPE; --zapis' tablici SL_TASK_MESS
  st     VARCHAR2(2000);
  i      BINARY_INTEGER;
  count1 BINARY_INTEGER;       --schetchik zapiseij v tablice SL_MESS
  count2 BINARY_INTEGER;       --schetchik zapiseij v tablice SL_TASK_MESS
BEGIN
  TT.DELETE;
  --formirovanie zagolovka dlya xml faila
  TT(1):='<?xml version="1.0" encoding="UTF-8" ?>';
  --vstavka usloviya kak atributa tablici SL_TASK_ROLE1
  IF Filter IS NULL THEN RETURN; END IF;
  st := 'cond="' || REPLACE(REPLACE(Filter, '&', '&amp;'), '''', '&apos;');
  TT(2):='<rowset table-name="'||UPPER(TableName)||'" '||REPLACE(REPLACE(st, '<', '&lt;'), '>', '&gt;')||'">';

  --kursor dlya SL_MESS
  OPEN c1 FOR 'SELECT * FROM '||TableName||' WHERE '||Filter||' ORDER BY MESS_ID, ITEM_NAME, TEXT, TEXT_B';

  --perebor zapisej po tablice SL_MESS
  i:=3;
  count1:=1;
  LOOP
    FETCH c1 INTO rec1;
    EXIT WHEN c1%NOTFOUND;
    TT(i):='<record_mess n="'||count1||'" mess_id="'||rec1.MESS_ID||'">'; i:=i+1;
    TT(i):='<MESS_ID>'||ReplaceST(rec1.MESS_ID)||'</MESS_ID>'; i:=i+1;
    TT(i):='<TEXT>'||ST_TO_16bits(REPLACE(ReplaceST(rec1.TEXT), '\', '$$'))||'</TEXT>'; i:=i+1;
    TT(i):='<ITEM_NAME>'||ReplaceST(rec1.ITEM_NAME)||'</ITEM_NAME>'; i:=i+1;
    TT(i):='<TEXT_B>'||ReplaceST(rec1.TEXT_B)||'</TEXT_B>'; i:=i+1;

    --kursor dlya SL_TASK_MESS
    OPEN c2 FOR 'SELECT * FROM SL_TASK_MESS WHERE MESS_ID='||rec1.MESS_ID||' ORDER BY TASK_NAME, MESS_ID';
    TT(i):='<recs_task_mess>'; i:=i+1;
    count2:=1;
    LOOP
      FETCH c2 INTO rec2;
      EXIT WHEN c2%NOTFOUND;
      TT(i):='<TASK_NAME id="'||count2||'">'||ReplaceST(rec2.TASK_NAME)||'</TASK_NAME>'; i:=i+1;
      count2:=count2+1;
    END LOOP;
    CLOSE c2;
    TT(i):='</recs_task_mess>'; i:=i+1;

    TT(i):='</record_mess>'; i:=i+1;
    count1:=count1+1;
  END LOOP;
  CLOSE c1;
  TT(i):='</rowset>';

  EXCEPTION WHEN OTHERS THEN
    if(c1%isopen)then close c1; end if;
    if(c2%isopen)then close c2; end if;
    RAISE_EXCEPTION(gc_packet,'ExpMess');
END;

function Imp_SL_MESS(p_file in varchar2)RETURN BOOLEAN IS
  parser  DBMS_XMLPARSER.Parser := DBMS_XMLPARSER.newParser;
  xmldoc  DBMS_XMLDOM.DOMDocument;
  rowsets DBMS_XMLDOM.DOMNodeList;
  node    DBMS_XMLDOM.DOMNode;
  rows_   DBMS_XMLDOM.DOMNodeList;
  fields  DBMS_XMLDOM.DOMNodeList;
  content DBMS_XMLDOM.DOMNode;
  nnm     DBMS_XMLDOM.DOMNamedNodeMap;

  tblname VARCHAR2(100);   -- table name
  fdef    VARCHAR2(32767); -- fields def for SL_TASK_ROLE1
  cont    VARCHAR2(32767); -- content
  cond    VARCHAR2(32767); -- conditional
  i       BINARY_INTEGER;
  j       BINARY_INTEGER;
  len     BINARY_INTEGER;
  flen    BINARY_INTEGER;
  messID  VARCHAR2(2000);
  bWarning boolean:=false;
BEGIN
  DBMS_XMLPARSER.parseCLOB(parser, var_clob); --privyazka parser k peremennoj clob
  xmldoc := DBMS_XMLPARSER.getDocument(parser); --poluchenie documenta xml

  rowsets := DBMS_XMLDOM.getElementsByTagName(xmldoc, 'rowset'); --poluchenie kornya documenta
  len := DBMS_XMLDOM.getLength(rowsets);
  --dbms_output.put_line('len=  '||len);

  node := DBMS_XMLDOM.item(rowsets, 0);
  nnm:=DBMS_XMLDOM.getAttributes(node); --poluchenie atributov v vide nesvyazannogo spiska
  tblname := DBMS_XMLDOM.getNodeValue(DBMS_XMLDOM.item(nnm, 0)); --poluchenie imeni tablici
  --dbms_output.put_line('tblname=  '||tblname);

  --poluchenie usloviya, po kotoromy predvaritel'no nujno udalit' zapisi
  cond := DBMS_XMLDOM.getNodeValue(DBMS_XMLDOM.item(nnm, 1));
  --dbms_output.put_line('cond=  '||cond);

  --udalenie zapisei po videlennomu usloviy
  EXECUTE IMMEDIATE 'DELETE FROM '||tblname||' WHERE '||cond;
  iis_z_log.warning('!!! -> DELETE FROM '||tblname||' WHERE '||cond);

  rows_:=DBMS_XMLDOM.getChildNodes(node); --nabor dochernih blocov zapisei v korne
  len:=DBMS_XMLDOM.getLength(rows_); --kolichestvo blocov zapisei
  IF len = 0 THEN
     rollback;
     iis_z_log.warning(p_file||'*'||'kolichestvo blocov zapisei(rowset is empty) in XML = 0');
     RETURN true;
  END IF; -- rowset is empty
  --dbms_output.put_line('len_2=  '||len);

  --poluchenie pervogo dochernego uzla bloca zapisei (, kotorij yavlyaetsya dochernim dlya root)
  fields:=DBMS_XMLDOM.getChildNodes(DBMS_XMLDOM.Item(rows_, 0));
  --poluchenie kolichestva uzlov v etom pervom dochernem
  flen:=DBMS_XMLDOM.getLength(fields);

  --poluchenie nazvanij uzlov, t.e. nazvanij stolbcov tablici SL_MESS
  --0..flen-2 oznachet bez poslednego nabora, kotorij otnositsya k SL_TASK_MESS
  fdef := '(';
  FOR j IN 0..flen-2 LOOP
    node := DBMS_XMLDOM.item(fields, j);
    fdef := fdef || DBMS_XMLDOM.getNodeName(node) || ',';
  END LOOP;
  fdef := RTRIM(fdef,',') || ')';
  --dbms_output.put_line('fdef=  '||fdef);

  len := DBMS_XMLDOM.getLength(rows_); --kolichestvo blocov zapisei v korne
  IF len = 0 THEN
    rollback;
    iis_z_log.warning(p_file||'*'||'kolichestvo blocov zapisei v korne in XML = 0');
    RETURN true;
  END IF; -- rowset is empty
  --cikl po blocam
  FOR i IN 0..len-1 LOOP
    fields := DBMS_XMLDOM.getChildNodes(DBMS_XMLDOM.Item(rows_, i));
    flen   := DBMS_XMLDOM.getLength(fields);
    IF flen = 1 THEN
      rollback;
      iis_z_log.warning(p_file||'*'||'net zapisej s takimi mess_id kak v uslovii in XML');
      return true;
    END IF; --kogda net zapisej s takimi mess_id kak v uslovii

    --poluchenie atributa - nomera soobsheniya
    rowsets := DBMS_XMLDOM.getElementsByTagName(xmldoc, 'record_mess');
    node := DBMS_XMLDOM.item(rowsets,i);
    nnm:=DBMS_XMLDOM.getAttributes(node);
    messID := DBMS_XMLDOM.getNodeValue(DBMS_XMLDOM.item(nnm, 1));
    --dbms_output.put_line(i||'      messID=  '||messID);

    cont   := '(';
    --cikl po stolbcam zapisi SL_MESS (0..flen-2)
    FOR j IN 0..flen-2 LOOP
      node:=DBMS_XMLDOM.item(fields, j);
      content:=DBMS_XMLDOM.getFirstChild(node);
      IF DBMS_XMLDOM.IsNull(content) THEN
        cont:=cont || 'NULL,';
    ELSE -- Is text node
        cont:=cont || '''' ||
                  REPLACE(REPLACE(
                    REPLACE(
                      REPLACE(
                        REPLACE(UNISTR(DBMS_XMLDOM.getNodeValue(content)),'''',''''''),
                        '&lt;', '<'), '&gt;', '>'),
                        '&amp;', '&'), '$$', '\') || ''',';
        cont:=replace(cont, chr(10));
      END IF;
    END LOOP;
    cont := RTRIM(cont,',') || ')';

    --dbms_output.put_line('cont=  '||cont);
    --vstavka zapisi v SL_MESS
    EXECUTE IMMEDIATE 'INSERT INTO '||tblname||fdef||' VALUES '||cont;

    ---------------------------------------------------------
    --(flen-1)-poslednij uzel v bloce, kotorij soderjit zapisi podchinennoj tablici SL_TASK_MESS
    node:=DBMS_XMLDOM.item(fields, flen-1);
    --razbor etogo poslednego uzla i vstavka zapisei v SL_TASK_MESS
    Imp_SL_TASK_MESS(node, messID,bWarning,p_file);
    ---------------------------------------------------------
   END LOOP;

  DBMS_XMLDOM.freeDocument(xmldoc);
  DBMS_XMLPARSER.freeParser(parser);
  dbms_lob.FreeTemporary(var_clob);
  COMMIT;
  return bWarning;

EXCEPTION WHEN OTHERS THEN
    rollback;
    DBMS_XMLDOM.freeDocument(xmldoc);
    DBMS_XMLPARSER.freeParser(parser);
    RAISE_EXCEPTION(gc_packet,'Imp_SL_MESS');
END;
